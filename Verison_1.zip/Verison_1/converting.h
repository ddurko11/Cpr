

// converting function prototype
// this function takes no parameters and returns no value.
void converting(void);
