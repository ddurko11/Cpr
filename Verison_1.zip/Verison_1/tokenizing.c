// TOKENIZING MODULE SOURCE
#define _CRT_SECURE_NO_WARNINGS


//macros
#define BUFFER_SIZE 300
#include <string.h>
//user library
#include "tokenizing.h"


// V1
//code execution. void function, returns nothing
void tokenizing(void) {
	// show message: *** Start of Tokenizing Words Demo***
	printf("*** Start of Tokenizing Words Demo ***\n");

	// Declare an array to store input words and a pointer for tokenizing
	char	words[BUFFER_SIZE];
	char*	nextWord = NULL;
	int		wordsCounter;

	// Start a loop for user input until "q" is entered
	do {
		// prompt message: Type a few words separated by space (q - to quit):
		printf("Type a few words separated by space (q - to quit):\n");

		// Read a line of input from the user and remove the trailing newline character
		fgets(words, BUFFER_SIZE, stdin);
		words[strlen(words) - 1] = '\0';

		// Check if the entered string is not "q"
		if (strcmp(words, "q") != 0) {
			nextWord = strtok(words, " ");
			wordsCounter = 1;

			// loop, print the current word and its position each time
			while (nextWord) {
				printf("Word #%d is \'%s\'\n", wordsCounter++, nextWord);

				// Get the next token
				nextWord = strtok(NULL, " ");

			}
			
		}
	} while (strcmp(words, "q") != 0);

	//show this message when the user enters "q"
	printf("*** End of Tokenizing Words Demo ***\n\n");
};

int main(void) {
	tokenizing();
	return 0;
}
