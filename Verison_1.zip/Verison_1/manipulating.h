//manipulating function prototype that doesn't take any paramaters and doesn't return any value
void manipulating();

