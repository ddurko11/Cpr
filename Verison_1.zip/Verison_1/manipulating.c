#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS
//macro
#define BUFFER_SIZE 80
//user library
//#include "manipulating.h"

//V1
//start of manipulating function
void maniulating(void) {
	//display message
	printf("*** Start of Concatenating Strings Demo ***\n");
	// declare character arrays
	char string1[BUFFER_SIZE * 2];
	char string2[BUFFER_SIZE];

	do {
		//display message prompting user to enter 1st string
		printf("Type the 1st string (q-to quit):\n");
		//store user input into variable string1
		fgets(string1, BUFFER_SIZE, stdin);
		//remove newline character from string1
		string1[strlen(string1) - 1] = '\0';
		//check if input was 'q' to exit loop
		if ((strcmp(string1, "q") != 0)) {
			//display message prompting user to enter 2nd string
			printf("Type the 2nd string:\n");
			//store user input into variable string2
			fgets(string2, BUFFER_SIZE, stdin);
			//remove newline character from string2
			string2[strlen(string2) - 1] = '\0';
			//
			strcat(string1, string2);
			//display message
			printf("Concatenated string is \'%s\'\n", string1);
		}
		//loop condition
	} while (strcmp(string1, "q") != 0);
	//display message
	printf("*** End of Concatenating Strings Demo ***\n\n");
}
int main(void)
{
	maniulating();
		return 0;
}
