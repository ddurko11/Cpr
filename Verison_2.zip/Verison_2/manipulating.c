#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

//macro
#define BUFFER_SIZE 80
#include "manipulating.h"

//V2
//start of manipulating function
void manipulating(void)
{
	//display message
	printf("*** Start of Concatenating Strings Demo ***\n");
	// declare character arrays
	char compare1[BUFFER_SIZE];
	char compare2[BUFFER_SIZE];
	int result;
	do {
		//display message prompting user to enter 1st string
		printf("Type the 1st string to compare (q-to quit):\n");
		//store user input into variable string1
		fgets(compare1, BUFFER_SIZE, stdin);
		//remove newline character from string1
		compare1[strlen(compare1) - 1] = '\0';
		//check if input was 'q' to exit loop
		if (strcmp(compare1, "q") != 0)
		{
			//display message prompting user to enter 2nd string
			printf("Type the 2nd string to compare:\n");
			//store user input into variable string2
			fgets(compare2, BUFFER_SIZE, stdin);
			//remove newline character from string2
			compare2[strlen(compare2) - 1] = '\0';
			// compares compare1 and compare2 and puts it into result
			result = strcmp(compare1, compare2);
			if (result < 0)
			{
				printf("\'%s\' string is less than \'%s\'\n", compare1, compare2);
			}
			else if (result == 0)
			{
				printf("\'%s\' string is equal to \'%s\'\n", compare1, compare2);
			}
			else
			{
				printf("\'%s\' string is greater than \'%s\'\n", compare1, compare2);
			}
		}
		//loop condition
	} while (strcmp(compare1, "q") != 0);
	//display message}
	printf("*** End of Concatenating Strings Demo ***\n");
}