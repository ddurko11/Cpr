// CONVERTING MODULE SOURCE
/*a preprocesssor directive to suppress warning related to
the use of certain functions that are considered unsafe*/
#define _CRT_SECURE_NO_WARNINGS

//defines a constant 'BUFFER_SIZE' with a value of 80
#define BUFFER_SIZE 80

//system library
#include <stdio.h>
//user-defined library
#include "converting.h"


//the definition of the function 'converting, this function takes no parameters and returns no value.
void converting(void)
{  
	//V1
	//prints a header indicating the start of the demonstration.
	printf("*** Start of Converting String to int Demo ***\n"); 
    
	//declare variable 'intString', a character array with a maximum size of "BUFFER_SIZE'
	char intString[BUFFER_SIZE]; 
    
	//declares variable 'intNumber' to store the converted number
	int intNumber; 

    //Starts a do-while loop that continues until the user inputs "q".
	do {   

        //prompts the user to enter a numeric string or "q" to quit.
		printf("Type an int numeric string (q - to quit):\n"); 

        //read a string input from the user, using fgets to ensure no buffer overflow.
		fgets(intString, BUFFER_SIZE, stdin); 

         // removes the newline character from the end of the string.
		intString[strlen(intString) - 1] = '\0'; 

        //checks if the entered string is not equal to "q".
		if (strcmp(intString, "q") != 0) {

            // converts the string to an integer using the atoi function.
			intNumber = atoi(intString); 

            //prints the converted integer.	
			printf("Converted number is %d\n", intNumber); 
		}

    //closes the do-while loop. The loop continues until the user enters "q".
	} while (strcmp(intString, "q") != 0); 

	//prints a message indicating the end of the demonstration.
	printf("*** End of Converting Strings to int Demo ***\n\n"); 



	//V2
	// Print a message indicating the start of the converting to double demo
	printf("*** Start of Converting to double Demo ***\n");

	// Declare a character array to store the input string
	char doubleString[BUFFER_SIZE];

	// Declare a variable to store the converted double number
	double doubleNumber;

	// Start a do-while loop to repeatedly prompt the user for input
	do {

		// Prompt the user to type the double numeric string (q - to quit)
		printf("Type the double numeric string (q - to quit):\n");

		// Read input from the user and store it in doubleString
		fgets(doubleString, BUFFER_SIZE, stdin);

		// Remove the newline character at the end of the input
		doubleString[strlen(doubleString) - 1] = '\0';

		// Check if the input is not 'q'
		if ((strcmp(doubleString, "q") != 0)) {

			// Convert the string to a double using atof function
			doubleNumber = atof(doubleString);

			// Print the converted double number
			printf("Converted number is %f\n", doubleNumber);
		}
		// Continue the loop until the input is 'q'
	} while (strcmp(doubleString, "q" != 0));

	// Print a message indicating the end of the converting to double demo
	printf("*** End of Converting Strings to double Demo ***\n\n");
}
	