// FUNDAMENTALS MODULE SOURCE


#define _CRT_SECURE_NO_WARNINGS //needed for scanf user input

//macros
#define BUFFER_SIZE 80
#define NUM_INPUT_SIZE 10


//user library
#include "fundamentals.h"

//start of fundamentals function
void fundamentals(void)
{
	// V1

	//display message - start of indexing strings
	printf("*** Start of Indexing Strings Demo ***\n");

	//declare character arrays
	char buffer1[BUFFER_SIZE];
	char numInput[NUM_INPUT_SIZE];

	//"size of" operator
	size_t position;


	do
	{
		//display message prompting user to enter a non-empty string		
		printf("Type not empty string q - to quit):\n");

		//store user input into variable buffer1
		fgets(buffer1, BUFFER_SIZE, stdin);

		//remove newline character from buffer1
		buffer1[strlen(buffer1) - 1] = '\0';

		//check if user input was 'q' - condition to exit the loop
		if (strcmp(buffer1, "q") != 0)
		{
			//display message prompting use to enter the character position
			printf("Type the character position within the string: \n");

			//store user input into variable numInput
			fgets(numInput, NUM_INPUT_SIZE, stdin);

			//remove newline character from numInput
			numInput[strlen(numInput) - 1] = '\0';

			//convert numInput into an integer and store it in the variable position
			position = atoi(numInput);

			//check if position is greater than or equal to the string length of buffer1
			if (position >= strlen(buffer1))
			{

				//update postion as 1 less than maximum available position
				position = strlen(buffer1) - 1;

				//display message stating the postion was reduced	
				printf("Too big... Position reduced to max. available\n");
			}

			//display message with character found at the postion	
			printf("The character found at %d position is \'%c\'\n", (int)position, buffer1[position]);
		}

		//loop condition, exit if user enters q
	} while (strcmp(buffer1, "q") != 0);

	//display ending message
	printf("*** End of Indexing Strings Demo ***\n\n");


	// V2

	//display message - start of measuring strings
	printf("*** Start of Measuring Strings Demo***\n");

	//declare character array
	char buffer2[BUFFER_SIZE];

	do
	{
		//display message prompting for user input
		printf("Type a string (q to quit):\n");

		//store user input into variable buffer2
		fgets(buffer2, BUFFER_SIZE, stdin);

		//remove newline character from buffer2
		buffer2[strlen(buffer2) - 1] = '\0';

		//check if user input was 'q' - condition to exit the loop
		if (strcmp(buffer2, "q") != 0)
		{
			//display message with number of characters in buffer2
			printf("The length of \'%s\' is %d characters\n", buffer2, (int)strlen(buffer2));
		}

	  //loop condition, exit if user enters q
	} while (strcmp(buffer2, "q") != 0);

	printf("*** End of Measuring Strings Demo ***\n\n)");
}
