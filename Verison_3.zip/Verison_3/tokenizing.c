// TOKENIZING MODULE SOURCE
#define _CRT_SECURE_NO_WARNINGS


//macros
#define BUFFER_SIZE 300
#include <string.h>
//user library
#include "tokenizing.h"



void tokenizing(void) {
	// V1
	
	// show message: *** Start of Tokenizing Words Demo***
	printf("*** Start of Tokenizing Words Demo ***\n");

	// Declare an array to store input words and a pointer for tokenizing
	char	words[BUFFER_SIZE];
	char*	nextWord = NULL;
	int		wordsCounter;

	// Start a loop for user input until "q" is entered
	do {
		// prompt message: Type a few words separated by space (q - to quit):
		printf("Type a few words separated by space (q - to quit):\n");

		// Read a line of input from the user and remove the trailing newline character
		fgets(words, BUFFER_SIZE, stdin);
		words[strlen(words) - 1] = '\0';

		// Check if the entered string is not "q"
		if (strcmp(words, "q") != 0) {
			nextWord = strtok(words, " ");
			wordsCounter = 1;

			// loop, print the current word and its position each time
			while (nextWord) {
				printf("Word #%d is \'%s\'\n", wordsCounter++, nextWord);

				// Get the next token
				nextWord = strtok(NULL, " ");

			}
			
		}
	} while (strcmp(words, "q") != 0);

	//show this message when the user enters "q"
	printf("*** End of Tokenizing Words Demo ***\n\n");

	// V2

	// show message: *** Start of Tokenizing Phrases Demo***
	printf("*** Start of Tokenizing Phrases Demo ***\n");

	// Declare an array to store input phrases and a pointer for tokenizing
	char	phrases[BUFFER_SIZE];
	char* nextPhrase = NULL;
	int		phrasesCounter;

	// Start a loop for user input until "q" is entered
	do {
		// prompt message: Type a few phrases separated by comma (q - to quit):
		printf("Type a few phrases separated by comma (q - to quit):\n");

		// Read a line of input from the user and remove the trailing newline character
		fgets(phrases, BUFFER_SIZE, stdin);
		phrases[strlen(phrases) - 1] = '\0';

		// Check if the entered string is not "q"
		if ((strcmp(phrases, "q") != 0)) {
			nextPhrase = strtok(phrases, ",");
			phrasesCounter = 1;

			// loop, print the current phrase and its position each time
			while (nextPhrase) {
				printf("Phrase #%d is \'%s\'\n", phrasesCounter++, nextPhrase);

				// Get the next token
				nextPhrase = strtok(NULL, ",");

			}

		}
	} while (strcmp(phrases, "q") != 0);

	//show this message when the user enters "q"
	printf("*** End of Tokenizing Phrases Demo ***\n\n");

	// V3

	// show message: *** Start of Tokenizing Phrases Demo***
	printf("*** Start of Tokenizing Sentences Demo ***\n");

	// Declare an array to store input sentences and a pointer for tokenizing
	char	sentences[BUFFER_SIZE];
	char* nextSentence = NULL;
	int		sentencesCounter;

	// Start a loop for user input until "q" is entered
	do {
		// prompt message: Type a few sentences separated by dot (q - to quit):
		printf("Type a few sentences separated by dot (q - to quit):\n");

		// Read a line of input from the user and remove the trailing newline character
		fgets(sentences, BUFFER_SIZE, stdin);
		sentences[strlen(sentences) - 1] = '\0';

		// Check if the entered string is not "q"
		if ((strcmp(sentences, "q") != 0)) {
			nextSentence = strtok(sentences, ".");
			sentencesCounter = 1;

			// loop, print the current phrase and its position each time
			while (nextSentence) {
				printf("Sentence #%d is \'%s\'\n", sentencesCounter++, nextSentence);

				// Get the next token
				nextSentence = strtok(NULL, ".");

			}

		}
	} while (strcmp(sentences, "q") != 0);

	//show this message when the user enters "q"
	printf("*** End of Tokenizing Sentences Demo ***\n\n");
};





//int main(void) {
//	tokenizing();
//	return 0;
//}
