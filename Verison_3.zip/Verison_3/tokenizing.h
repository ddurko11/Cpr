#pragma once
// TOKENIZING MODULE HEADER
#pragma once
#ifndef _TOKENIZING_H_
#define _TOKENIZING_H_

#include <stdio.h>
#include <string.h>

void tokenizing(void);

#endif
