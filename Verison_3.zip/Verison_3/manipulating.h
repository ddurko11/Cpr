#pragma once
#include <stdio.h>
#include <string.h>
void manipulating(void);